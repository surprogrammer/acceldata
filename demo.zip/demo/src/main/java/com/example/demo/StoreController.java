package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
public class StoreController {

    @Autowired
    StoreService storeService;

    @GetMapping(value = "/")
    public String home(){
        return "Persistence Application";
    }

    @PostMapping(value = "/create")
    public ResponseEntity createRecord(@RequestBody CreateRequest createRequest){
        ResponseEntity responseEntity = null;
        try {
            responseEntity = storeService.createStoreData(createRequest);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return responseEntity;
    }

    @GetMapping(value = "/getRecord/{key}")
    public String getRecord(@PathVariable String key){
        ResponseEntity responseEntity = null;
        try {
            return storeService.getDataByKey(key);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @DeleteMapping(value = "/deleteRecord/{key}")
    public ResponseEntity deleteRecord(@PathVariable String key){
        ResponseEntity responseEntity = null;
        try {
             storeService.deleteDataByKey(key);
             return new ResponseEntity( HttpStatus.OK );
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR );
        }
    }

    @PatchMapping(value = "/updateRecord")
    public ResponseEntity updateRecord(@RequestBody CreateRequest createRequest){
        ResponseEntity responseEntity = null;
        try {
            storeService.updateDataByKey(createRequest);
            return new ResponseEntity( HttpStatus.OK );
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR );
        }
    }
}
