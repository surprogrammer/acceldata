package com.example.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.IOException;


public interface StoreService {

    void createStore(CreateRequest createRequest) throws IOException;
    ResponseEntity createStoreData(CreateRequest createRequest) throws IOException;
    CreateRequest getData(String key) throws IOException;
    String getDataByKey(String key) throws IOException;
    void deleteDataByKey(String key) throws IOException;
    void updateDataByKey(CreateRequest createRequest) throws IOException;
}
