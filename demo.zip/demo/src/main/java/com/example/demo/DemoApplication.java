package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run( DemoApplication.class, args );

        /*StoreServiceImpl storeService = new StoreServiceImpl();
        try {
            storeService.createStore( new CreateRequest("1", "dummy") );
            storeService.getData( "1" );
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }

}
