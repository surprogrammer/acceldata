package com.example.demo;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.opencsv.CSVWriter;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import org.json.simple.parser.JSONParser;



@Service
public class StoreServiceImpl implements StoreService {

    static int count =0;
    @Override
    public void createStore(CreateRequest createRequest) throws IOException {
        // Using file pointer creating the file.
        File file = new File("store.txt");

        if (!file.exists()) {
            // Create a new file if not exists.
            file.createNewFile();
        }

        try {
            // create FileWriter object with file as parameter
            FileWriter outputfile = new FileWriter(file);
            Scanner sc = new Scanner(file);

            // create CSVWriter object filewriter object as parameter
            CSVWriter writer = new CSVWriter(outputfile);

            // adding header to csv
           /* String[] header = { "ID", "Key", "Value" };
            writer.writeNext(header);*/

            // add data to csv
           /* String[] data1 = { "1", "1", "value1" };
            writer.writeNext(data1);
            String[] data2 = { "2", "2", "value2" };
            writer.writeNext(data2);*/

            // adding request

            String[] data = {String.valueOf( count+1),createRequest.getKey(), createRequest.getValue()};
            writer.writeNext(data);
            // closing writer connection
            writer.close();
        }
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Override
    public ResponseEntity createStoreData(CreateRequest createRequest) throws IOException {
        // Using file pointer creating the file.
        File file = new File("D:\\FullStack\\demo\\store.json");
        if (!file.exists()) {
            // Create a new file if not exists.
            file.createNewFile();
        }
        try {
        // Read data from JSON
        JSONParser jsonParser = new JSONParser(  );
        //Parsing the contents of the JSON file
        JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader("D:\\FullStack\\demo\\store.json"));
        FileWriter fileWriter = new FileWriter( "store.json" );
        JSONObject jsonObject = new JSONObject();
        jsonObject.put( createRequest.getKey(), createRequest.getValue() );
        jsonArray.add( jsonObject );
        fileWriter.write(jsonArray.toJSONString());
        fileWriter.close();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new ResponseEntity( HttpStatus.CREATED );
    }

    @Override
    public CreateRequest getData(String key) throws IOException {
        File f1=new File("store.json"); //Creation of File Descriptor for input file
        String[] words=null;  //Intialize the word Array
        FileReader fr = new FileReader(f1);  //Creation of File Reader object
        BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
        Scanner scanner = new Scanner(f1);
        String s;
        ///String input="Java";   // Input word to be searched
        int count=0;   //Intialize the word to zero
        //while((s=br.readLine())!=null)   //Reading Content from the file
        while(scanner.hasNext())   //Reading Content from the file
        {
            System.out.println("crrent line:"+br.readLine());
            s = br.readLine();
            List <String> list= br.lines().collect( Collectors.toList() );
            words=s.split(",");  //Split the word using space
            for (String word : list)
            {
                if (word.equals(key))   //Search for the given word
                {
                    count++;    //If Present increase the count by one
                }
            }
        }
        if(count!=0)  //Check for count not equal to zero
        {
            System.out.println("The given word is present for "+count+ " Times in the file");
        }
        else
        {
            System.out.println("The given word is not present in the file");
        }

        fr.close();

        return new CreateRequest(  );
    }

    public String getDataByKey(String key) throws IOException {
        try {
            JSONParser jsonParser = new JSONParser();
            //Parsing the contents of the JSON file
            JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader("D:\\FullStack\\demo\\store.json"));
            Gson gson = new Gson();
            JSONObject jsonObject = new JSONObject(  );
            for(Object object : jsonArray) {
                if(object instanceof JSONObject){
                  jsonObject = (JSONObject) jsonParser.parse( String.valueOf( (JSONObject) object ) );
                  if(jsonObject.containsKey( key )) break;
                }
            }
            return  jsonObject.toString();
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void deleteDataByKey(String key) throws IOException {
        try {
            JSONParser jsonParser = new JSONParser();
            //Parsing the contents of the JSON file
            JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader("D:\\FullStack\\demo\\store.json"));
            Gson gson = new Gson();
            JSONObject jsonObject = new JSONObject(  );
            JSONArray updatedJsonArray = new JSONArray();
            for(Object object : jsonArray) {
                if(object instanceof JSONObject){
                    jsonObject = (JSONObject) jsonParser.parse( String.valueOf( (JSONObject) object ) );
                    if(jsonObject.containsKey( key ))
                        jsonObject.remove( key );

                    else
                        updatedJsonArray.add( jsonObject );
                }
            }
            FileWriter fileWriter = new FileWriter( "store.json" );
            fileWriter.write(updatedJsonArray.toJSONString());
            fileWriter.close();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateDataByKey(CreateRequest createRequest) throws IOException {
        try {
            JSONParser jsonParser = new JSONParser();
            //Parsing the contents of the JSON file
            JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader("D:\\FullStack\\demo\\store.json"));
            Gson gson = new Gson();
            JSONObject jsonObject = new JSONObject(  );
            JSONArray updatedJsonArray = new JSONArray();
            for(Object object : jsonArray) {
                if(object instanceof JSONObject){
                    jsonObject = (JSONObject) jsonParser.parse( String.valueOf( (JSONObject) object ) );
                    if(jsonObject.containsKey( createRequest.getKey() ))
                        jsonObject.put( createRequest.getKey(), createRequest.getValue() );
                }
                updatedJsonArray.add( jsonObject );
            }
            FileWriter fileWriter = new FileWriter( "store.json" );
            fileWriter.write(updatedJsonArray.toJSONString());
            fileWriter.close();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
